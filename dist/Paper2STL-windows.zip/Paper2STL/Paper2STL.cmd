@echo off
setlocal
set "VENV=%LOCALAPPDATA%\Paper2STL\venv"
set "MARKER=%VENV%\.paper2stl_installed"
if exist "%VENV%\Scripts\pythonw.exe" if exist "%MARKER%" (
    start "" "%VENV%\Scripts\pythonw.exe" -m paper2stl.gui
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0resources\bootstrap.ps1"
