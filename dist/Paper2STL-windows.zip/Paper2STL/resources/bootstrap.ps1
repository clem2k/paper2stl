# Paper2STL - first launch: automatic environment setup.
$ErrorActionPreference = 'Stop'
function Info($m) { Write-Host ">> $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "OK $m" -ForegroundColor Green }
function Warn($m) { Write-Host " ! $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host ""; Write-Host "ERROR: $m" -ForegroundColor Red; Read-Host "Press Enter to close"; exit 1 }

$Res     = Split-Path -Parent $MyInvocation.MyCommand.Path
$SrcDir  = Join-Path $Res 'src'
$Support = Join-Path $env:LOCALAPPDATA 'Paper2STL'
$Venv    = Join-Path $Support 'venv'
$Marker  = Join-Path $Venv '.paper2stl_installed'
$VPy     = Join-Path $Venv 'Scripts\python.exe'
$VPyw    = Join-Path $Venv 'Scripts\pythonw.exe'

Clear-Host
Write-Host "=== Paper2STL - First-time installation ===" -ForegroundColor White
Write-Host "This step runs only ONCE; later launches will be instant."
Write-Host ""

# -- find Python 3.10+ --
Info "Looking for Python 3.10 or newer..."
$found = $null
$cands = @(@('py','-3.13'),@('py','-3.12'),@('py','-3.11'),@('py','-3.10'),@('py','-3'),@('python'),@('python3'))
foreach ($c in $cands) {
    $exe  = $c[0]
    $rest = @(); if ($c.Count -gt 1) { $rest = $c[1..($c.Count - 1)] }
    try {
        $v = & $exe @rest -c "import sys;print('%d.%d'%sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -eq 0 -and $v) {
            $p = $v.Trim().Split('.')
            if ([int]$p[0] -ge 3 -and [int]$p[1] -ge 10) {
                $found = @{ Exe = $exe; Args = $rest; Ver = $v.Trim() }
                break
            }
        }
    } catch { }
}
if (-not $found) {
    Warn "Python 3.10+ not found."
    Write-Host "   Install Python from https://www.python.org/downloads/windows/ then relaunch."
    Start-Process "https://www.python.org/downloads/windows/"
    Die "Python 3.10+ is required."
}
Ok ("Found: Python " + $found.Ver)
Write-Host ""

New-Item -ItemType Directory -Force -Path $Support | Out-Null

# -- double-launch lock (self-healing via PID) --
$Lock = Join-Path $Support '.install.lock'
if (Test-Path $Lock) {
    $oldpid = (Get-Content (Join-Path $Lock 'pid') -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($oldpid -and (Get-Process -Id ([int]$oldpid) -ErrorAction SilentlyContinue)) {
        Warn "An installation is already running (PID $oldpid). Close the other window."
        Start-Sleep 4; exit 0
    }
    Remove-Item -Recurse -Force $Lock
}
New-Item -ItemType Directory -Force -Path $Lock | Out-Null
"$PID" | Out-File -FilePath (Join-Path $Lock 'pid') -Encoding ascii

try {
    function Test-Venv {
        if (-not (Test-Path $VPy)) { return $false }
        & $VPy -m pip --version *> $null
        return ($LASTEXITCODE -eq 0)
    }

    if (-not (Test-Venv)) {
        Info "Creating the environment..."
        if (Test-Path $Venv) { Remove-Item -Recurse -Force $Venv }   # rebuild if incomplete
        & $found.Exe @($found.Args) -m venv $Venv
        if ($LASTEXITCODE -ne 0) { Die "Could not create the virtual environment." }
        # Guarantee pip inside the venv.
        & $VPy -m pip --version *> $null
        if ($LASTEXITCODE -ne 0) { & $VPy -m ensurepip --upgrade *> $null }
        if (-not (Test-Venv)) { Die "Could not install pip into the environment." }
    }

    Info "Updating pip..."
    & $VPy -m pip install --upgrade pip --disable-pip-version-check

    Write-Host ""
    Info "Installing dependencies (~400 MB, one time)..."
    Write-Host "   Please wait - PySide6, OpenCV, NumPy are downloading."
    Write-Host ""
    & $VPy -m pip install "$SrcDir"
    if ($LASTEXITCODE -ne 0) { Die "Dependency installation failed." }

    New-Item -ItemType File -Force -Path $Marker | Out-Null
    Write-Host ""
    Ok "Installation complete."

    # Desktop shortcut (launches with pythonw -> no console window).
    try {
        $ws  = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Paper2STL.lnk'))
        $lnk.TargetPath       = $VPyw
        $lnk.Arguments        = '-m paper2stl.gui'
        $lnk.WorkingDirectory = $Venv
        $lnk.Save()
        Ok "Desktop shortcut created."
    } catch { }

    Info "Launching Paper2STL..."
    Start-Process $VPyw -ArgumentList '-m', 'paper2stl.gui'
}
finally {
    Remove-Item -Recurse -Force $Lock -ErrorAction SilentlyContinue
}
